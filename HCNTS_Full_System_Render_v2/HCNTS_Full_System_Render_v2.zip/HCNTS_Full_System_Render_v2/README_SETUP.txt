This is the HCNTS Render-ready package. Upload to GitHub then deploy on Render.
